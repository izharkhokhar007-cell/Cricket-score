# CricGo - Live Cricket Score App for Acode

This project contains the complete source code for the CricGo Flutter application, specifically formatted for use with the Acode mobile editor.

## File-to-Path Mapping

Here is a list of all the files included in this project and their respective paths:

- `README.md`
- `pubspec.yaml`
- `assets/images/placeholder.png` (You will need to create this placeholder image)
- `assets/videos/sample_video.mp4` (You will need to create this placeholder video)
- `lib/main.dart`
- `lib/config/app_config.dart`
- `lib/models/match_model.dart`
- `lib/models/team_model.dart`
- `lib/models/score_model.dart`
- `lib/services/api_service.dart`
- `lib/services/cache_service.dart`
- `lib/providers/matches_provider.dart`
- `lib/providers/favorites_provider.dart`
- `lib/providers/admin_provider.dart`
- `lib/screens/home_screen.dart`
- `lib/screens/matches_screen.dart`
- `lib/screens/match_details_screen.dart`
- `lib/screens/video_screen.dart`
- `lib/screens/wodiwc_screen.dart`
- `lib/screens/more_screen.dart`
- `lib/screens/user_panel_screen.dart`
- `lib/screens/admin_login_screen.dart`
- `lib/screens/admin_dashboard_screen.dart`
- `lib/widgets/match_card.dart`
- `lib/widgets/score_badge.dart`
- `lib/widgets/loading_widget.dart`
- `lib/widgets/error_widget.dart`
- `lib/widgets/bottom_nav.dart`
- `lib/utils/date_utils.dart`
- `lib/utils/network_utils.dart`
- `test/widget_test.dart`

---

## Step-by-Step "Paste into Acode" Guide

Follow these instructions to set up the project in Acode on your Android device.

1.  **Open Acode** and create a new folder named `CricGo`.
2.  **Navigate into the `CricGo` folder.**
3.  **Create Sub-folders**:
    *   Create a folder named `lib`.
    *   Inside `lib`, create folders: `config`, `models`, `services`, `providers`, `screens`, `widgets`, `utils`.
    *   Create a folder named `assets`.
    *   Inside `assets`, create folders: `images`, `videos`.
    *   Create a folder named `test`.

4.  **Create and Paste Files**:
    *   In the root `CricGo` folder, create a new file named `pubspec.yaml`.
    *   Copy the content from the `pubspec.yaml` code block below and paste it into the file. Save it.
    *   Repeat this process for every file listed above, ensuring you create the file in the correct directory as specified in the `// SAVE:` header comment.

5.  **Add Assets**:
    *   You will need to add a placeholder image and video.
    *   Place any `.png` image inside `assets/images/` and name it `placeholder.png`.
    *   Place any `.mp4` video inside `assets/videos/` and name it `sample_video.mp4`.

---

## How to Change the API Key

The API key is stored in a central configuration file.

1.  Open the file: `lib/config/app_config.dart`.
2.  Locate the line: `static const String cricketApiKey = 'YOUR_API_KEY';`
3.  Replace `'YOUR_API_KEY'` with your new API key from `cricapi.com`.

---

## How to Transfer and Run on a Desktop

To build and run this project, you need the Flutter SDK installed on your computer (Windows/macOS/Linux).

1.  **Transfer Files**: Copy the entire `CricGo` folder from your phone to your computer.
2.  **Open Terminal/CMD**: Navigate into the `CricGo` project directory.
    ```sh
    cd path/to/your/CricGo
    ```
3.  **Get Dependencies**: Run the following command to download the required packages.
    ```sh
    flutter pub get
    ```
4.  **Run the App**: Connect a device or start an emulator, then run:
    ```sh
    flutter run
    ```

---

## Optional: Build on Android (Advanced)

Building a Flutter app directly on an Android device is possible but complex. It requires a powerful device and a terminal environment like Termux.

1.  **Install Termux**: Get Termux from F-Droid.
2.  **Install Dependencies**: Inside Termux, you would need to install a proot-distro of a Linux distribution (like Ubuntu) and then install the Flutter SDK, Android SDK, and all required build tools within that Linux environment.
3.  **Build**: The process is highly technical and involves many steps. For most users, transferring the project to a desktop is the recommended approach. You can also explore cloud-based CI/CD services like Codemagic, which can build the app for you from a Git repository.