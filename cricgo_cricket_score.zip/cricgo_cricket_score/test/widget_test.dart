import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';
import 'package:cricgo/providers/matches_provider.dart';
import 'package:cricgo/screens/matches_screen.dart';

void main() {
  testWidgets('MatchesScreen shows loading indicator initially', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => MatchesProvider()),
        ],
        child: const MaterialApp(
          home: MatchesScreen(),
        ),
      ),
    );

    // Verify that a loading indicator is shown.
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    // You would typically mock the API call here to test success/error states.
    // For this minimal test, we'll just check the initial state.
  });
}