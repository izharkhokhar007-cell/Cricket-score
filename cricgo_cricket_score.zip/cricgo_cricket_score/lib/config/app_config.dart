// lib/config/app_config.dart
// CricGo App Configuration File

class AppConfig {
  // 👇 CricAPI ka base URL
  static const String baseUrl = "https://api.cricapi.com/v1/currentMatches?apikey=4d235da0-0e26-4feb-b06b-66506748c815";

  // 👇 API key — apni khud ki key yahan daalo
  // Gemini ne demo key use ki thi, tum apni free key cricapi.com se le lo
  static const String apiKey = "YOUR_API_KEY_HERE";

  // 👇 App name (for reference)
  static const String appName = "CricGo";

  // 👇 App version
  static const String version = "1.0.0";

  // 👇 API endpoints
  static const String matchesEndpoint = "${baseUrl}matches";
  static const String matchDetailsEndpoint = "${baseUrl}match_info";
  static const String playerStatsEndpoint = "${baseUrl}player_info";
}