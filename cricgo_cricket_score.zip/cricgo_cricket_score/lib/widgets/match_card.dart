import 'package:flutter/material.dart';
import 'package:cricgo/models/match_model.dart';
import 'package:cricgo/screens/match_details_screen.dart';
import 'package:provider/provider.dart';
import 'package:cricgo/providers/favorites_provider.dart';

class MatchCard extends StatelessWidget {
  final Match match;

  const MatchCard({Key? key, required this.match}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final favoritesProvider = Provider.of<FavoritesProvider>(context);
    final isFavorite = favoritesProvider.isFavorite(match.id);

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => MatchDetailsScreen(match: match),
          ),
        );
      },
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                match.name,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              Text(match.status, style: TextStyle(color: Colors.yellow[600])),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('${match.team1.name} vs ${match.team2.name}'),
                  IconButton(
                    icon: Icon(
                      isFavorite ? Icons.bookmark : Icons.bookmark_border,
                      color: isFavorite ? Colors.blue : null,
                    ),
                    onPressed: () {
                      favoritesProvider.toggleFavorite(match.id);
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}