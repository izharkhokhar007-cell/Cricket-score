import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class CacheService {
  static const String _matchesCacheKey = 'last_matches_response';

  Future<void> cacheMatchesResponse(String responseBody) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_matchesCacheKey, responseBody);
  }

  Future<Map<String, dynamic>?> getLastMatchesResponse() async {
    final prefs = await SharedPreferences.getInstance();
    final cachedData = prefs.getString(_matchesCacheKey);
    if (cachedData != null) {
      return json.decode(cachedData);
    }
    return null;
  }
}