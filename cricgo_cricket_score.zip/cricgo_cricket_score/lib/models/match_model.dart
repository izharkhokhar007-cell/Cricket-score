import 'package:cricgo/models/score_model.dart';
import 'package:cricgo/models/team_model.dart';

class Match {
  final String id;
  final String name;
  final String status;
  final String matchType;
  final DateTime date;
  final Team team1;
  final Team team2;
  final List<Score> scores;

  Match({
    required this.id,
    required this.name,
    required this.status,
    required this.matchType,
    required this.date,
    required this.team1,
    required this.team2,
    required this.scores,
  });

  factory Match.fromJson(Map<String, dynamic> json) {
    var scoreList = json['score'] as List? ?? [];
    List<Score> scores = scoreList.map((s) => Score.fromJson(s)).toList();

    return Match(
      id: json['id'] ?? 'N/A',
      name: json['name'] ?? 'Untitled Match',
      status: json['status'] ?? 'No status',
      matchType: json['matchType'] ?? 'N/A',
      date: DateTime.tryParse(json['dateTimeGMT'] ?? '') ?? DateTime.now(),
      team1: Team(
          name: json['teams']?[0] ?? 'Team 1',
          shortName: json['teamInfo']?[0]?['shortname'] ?? 'T1'),
      team2: Team(
          name: json['teams']?[1] ?? 'Team 2',
          shortName: json['teamInfo']?[1]?['shortname'] ?? 'T2'),
      scores: scores,
    );
  }
}