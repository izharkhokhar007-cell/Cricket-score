// SAVE: lib/models/score_model.dart
```dart
class Score {
  final int runs;
  final int wickets;
  final double overs;

  Score({required this.runs, required this.wickets, required this.overs});

  factory Score.fromJson(Map<String, dynamic> json) {
    return Score(
      runs: json['r'] ?? 0,
      wickets: json['w'] ?? 0,
      overs: (json['o'] ?? 0.0).toDouble(),
    );
  }
}