import 'package:http/http.dart' as http;

class NetworkUtils {
  static Future<bool> isConnected() async {
    try {
      // Ping a reliable server to check for internet connection.
      final response = await http.get(Uri.parse('https://www.google.com')).timeout(const Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}