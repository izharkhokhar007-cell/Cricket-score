import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cricgo/providers/matches_provider.dart';
import 'package:cricgo/widgets/match_card.dart';
import 'package:cricgo/widgets/loading_widget.dart';
import 'package:cricgo/widgets/error_widget.dart' as custom;

class MatchesScreen extends StatefulWidget {
  const MatchesScreen({Key? key}) : super(key: key);

  @override
  _MatchesScreenState createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen> {
  @override
  void initState() {
    super.initState();
    // Start polling when the screen is first created
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Provider.of<MatchesProvider>(context, listen: false).startPolling();
    });
  }

  @override
  void dispose() {
    // Stop polling when the screen is disposed
    Provider.of<MatchesProvider>(context, listen: false).stopPolling();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MatchesProvider>(
      builder: (context, provider, child) {
        if (provider.isLoading && provider.matches.isEmpty) {
          return const LoadingWidget();
        }

        if (provider.error != null && provider.matches.isEmpty) {
          return custom.ErrorWidget(
            message: provider.error!,
            onRetry: () => provider.fetchMatches(),
          );
        }

        if (provider.matches.isEmpty) {
          return const Center(child: Text('No live matches right now.'));
        }

        return RefreshIndicator(
          onRefresh: () => provider.fetchMatches(),
          child: ListView.builder(
            itemCount: provider.matches.length,
            itemBuilder: (context, index) {
              final match = provider.matches[index];
              return MatchCard(match: match);
            },
          ),
        );
      },
    );
  }
}