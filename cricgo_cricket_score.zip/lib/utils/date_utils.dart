import 'package:intl/intl.dart';

String formatDateTime(DateTime dateTime) {
  return DateFormat('MMM dd, yyyy - hh:mm a').format(dateTime);
}