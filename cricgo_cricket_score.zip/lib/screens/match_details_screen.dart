import 'package:flutter/material.dart';
import 'package:cricgo/models/match_model.dart';
import 'package:cricgo/widgets/score_badge.dart';
import 'package:cricgo/utils/date_utils.dart';

class MatchDetailsScreen extends StatelessWidget {
  final Match match;

  const MatchDetailsScreen({Key? key, required this.match}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(match.name),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              match.name,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Status: ${match.status}',
              style: TextStyle(fontSize: 18, color: Colors.yellow[700]),
            ),
            const SizedBox(height: 8),
            Text('Type: ${match.matchType}', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 8),
            Text('Date: ${formatDateTime(match.date)}', style: const TextStyle(fontSize: 16)),
            const Divider(height: 32),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(match.team1.name, style: const TextStyle(fontSize: 20)),
                const Text('vs', style: TextStyle(fontSize: 20)),
                Text(match.team2.name, style: const TextStyle(fontSize: 20)),
              ],
            ),
            const SizedBox(height: 24),
            const Text(
              'Scores:',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            if (match.scores.isNotEmpty)
              ...match.scores.map((score) => ScoreBadge(score: score)).toList()
            else
              const Text('Scores not available yet.'),
          ],
        ),
      ),
    );
  }
}