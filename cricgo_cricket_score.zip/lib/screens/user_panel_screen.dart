import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:cricgo/providers/favorites_provider.dart';
import 'package:cricgo/providers/matches_provider.dart';
import 'package:cricgo/widgets/match_card.dart';

class UserPanelScreen extends StatelessWidget {
  const UserPanelScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final favoritesProvider = Provider.of<FavoritesProvider>(context);
    final matchesProvider = Provider.of<MatchesProvider>(context);
    final favoriteMatches = favoritesProvider.getFavoriteMatches(matchesProvider.matches);

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Favorites'),
      ),
      body: favoriteMatches.isEmpty
          ? const Center(
              child: Text('You have not favorited any matches yet.'),
            )
          : ListView.builder(
              itemCount: favoriteMatches.length,
              itemBuilder: (context, index) {
                return MatchCard(match: favoriteMatches[index]);
              },
            ),
    );
  }
}