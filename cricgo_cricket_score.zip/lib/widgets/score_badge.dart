import 'package:flutter/material.dart';
import 'package:cricgo/models/score_model.dart';

class ScoreBadge extends StatelessWidget {
  final Score score;

  const ScoreBadge({Key? key, required this.score}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.grey[800],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        '${score.runs}/${score.wickets} (${score.overs})',
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
      ),
    );
  }
}