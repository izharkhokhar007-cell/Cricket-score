import 'package:flutter/material.dart';
import 'package:cricgo/config/app_config.dart';

class AdminProvider with ChangeNotifier {
  bool _isAdminLoggedIn = false;

  bool get isAdminLoggedIn => _isAdminLoggedIn;

  Future<bool> login(String email, String password) async {
    if (email == AppConfig.adminEmail && password == AppConfig.adminPassword) {
      _isAdminLoggedIn = true;
      notifyListeners();
      return true;
    }
    return false;
  }

  void logout() {
    _isAdminLoggedIn = false;
    notifyListeners();
  }
}