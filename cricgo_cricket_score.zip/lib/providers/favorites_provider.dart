import 'package:flutter/foundation.dart';

class FavoritesProvider with ChangeNotifier {
  final List<String> _favoriteMatchIds = [];

  List<String> get favoriteMatchIds => _favoriteMatchIds;

  void toggleFavorite(String matchId) {
    if (_favoriteMatchIds.contains(matchId)) {
      _favoriteMatchIds.remove(matchId);
    } else {
      _favoriteMatchIds.add(matchId);
    }
    notifyListeners();
  }

  bool isFavorite(String matchId) {
    return _favoriteMatchIds.contains(matchId);
  }
}