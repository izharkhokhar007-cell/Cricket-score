/*fonts*/
const fontRegular = 'Regular';
const fontMedium = 'Medium';
const fontSemiBold = 'Semibold';
const fontBold = 'Bold';
const BaseUrl = 'https://api.cricapi.com/v1/currentMatches?apikey=4d235da0-0e26-4feb-b06b-66506748c815
